(function() {
    var options = {
        stringsElement: '#prompt',
        typeSpeed: 40
    };

    var typed = new Typed('#typed', options);


})();