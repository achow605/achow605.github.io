(function() {
    'use strict';

    AOS.init();

    let cardContainer = document.querySelector('.card-container');
    let card = document.querySelector('.card');
    let text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laboru";

    processText(card, cardContainer, text);

    function resize_to_fit(card, CardContainer) {
        let fontSize = window.getComputedStyle(card).fontSize;
        card.style.fontSize = (parseFloat(fontSize) - 1) + 'px';

        if (card.clientHeight >= cardContainer.clientHeight) {
            resize_to_fit(card, cardContainer);
        }
    }

    function processText(card, cardContainer, text) {
        card.innerHTML = text;
        card.style.fontSize = '100px'; // Default font size
        resize_to_fit(card, cardContainer);
    }
})();